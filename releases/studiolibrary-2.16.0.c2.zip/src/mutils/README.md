# Welcome to mutils!

`mutils` is a python package containing many Maya utility functions for managing poses and animations in Maya.

* www.studiolibrary.com
