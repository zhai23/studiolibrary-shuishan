# -*- coding: UTF-8 -*-
# Copyright 2020 by Kurt Rathjen. All Rights Reserved.
#
# This library is free software: you can redistribute it and/or modify it 
# under the terms of the GNU Lesser General Public License as published by 
# the Free Software Foundation, either version 3 of the License, or 
# (at your option) any later version. This library is distributed in the 
# hope that it will be useful, but WITHOUT ANY WARRANTY; without even the 
# implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
# See the GNU Lesser General Public License for more details.
# You should have received a copy of the GNU Lesser General Public
# License along with this library. If not, see <http://www.gnu.org/licenses/>.
import subprocess
import maya.cmds as cmds
import os
import sys
# 获取当前脚本文件的绝对路径
script_path = os.path.abspath(__file__)

# 获取脚本所在目录
script_directory = os.path.dirname(script_path)


hitokotoexe_path = '{}\\hitokoto_api.exe hitokoto_api.exe'.format(script_directory)
if sys.version_info[0] == 2:
    print(u"一言 Python 2")
    # 使用subprocess.Popen运行可执行文件，并捕获其输出
    process = subprocess.Popen(hitokotoexe_path, stdout=subprocess.PIPE)
    output, _ = process.communicate()
    # 手动解码并处理编码问题
    hitokoto = output.decode(sys.getfilesystemencoding(), errors='replace').strip()
elif sys.version_info[0] == 3:
    print(u"一言 Python 3")
    # 使用subprocess.run运行可执行文件，并捕获其输出
    result = subprocess.run(hitokotoexe_path, capture_output=True, text=True, shell=True)
    hitokoto = result.stdout
else:
    print(u"一言 未知的 Python 版本")
__version__ = hitokoto




def version():
    """
    Return the current version of the Studio Library

    :rtype: str
    """
    return __version__


from studiolibrary import config
from studiolibrary import resource
from studiolibrary.utils import *
from studiolibrary.library import Library
from studiolibrary.libraryitem import LibraryItem
from studiolibrary.main import main
